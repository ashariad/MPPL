<!DOCTYPE HTML>
<html>
	<head>
		<title>RM. Prambanan Gudeg Jogja</title>
		<meta name="viewport" content="width=1120,user-scalable=no" />
		<meta http-equiv="content-type" content="text/html; charset=utf-8" />
		<meta name="description" content="" />
		<meta name="keywords" content="" />
		<link href="http://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400" rel="stylesheet" type="text/css" />
		<script src="js/jquery.min.js"></script>
		<script src="js/jquery.poptrox.min.js"></script>
		<script src="js/config.js"></script>
		<script src="js/skel.min.js"></script>
		<noscript>
			<link rel="stylesheet" href="css/skel-noscript.css" />
			<link rel="stylesheet" href="css/style.css" />
			<link rel="stylesheet" href="css/style-desktop.css" />
			<link rel="stylesheet" href="css/style-noscript.css" />
		</noscript>
		
	</head>
	<body style="background: url('images/background.jpg')">

		<div id="wrapper">

			<div id="logo" >
						<article class="item thumb" data-width="175" style="border-radius:400px">
							<a href="index"><img src="images/rm2.png" style="border-radius:400px"></a>
						</article>
				
			</div>
		</div>

	</body>
</html>